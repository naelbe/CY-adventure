//
// Created by Benjamin Arbousset on 13/05/2023.
//

#ifndef COGNOOO_START_H
#define COGNOOO_START_H
int start();
#endif //COGNOOO_START_H


#ifndef COGNOOO_TYPE_H
#define COGNOOO_TYPE_H
void type(char *buffer);
#endif //COGNOOO_TYPE_H

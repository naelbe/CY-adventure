#include "../readint.h"
#include "../system/type.h"
#include "../system/sys.h"


void endWin(){

type("Vous avez triomphe de cette dangereuse aventure !\n");
type("Il vous reste des dizaines d'histoires alternatives a explorer, alors ne perdez pas de temps et continuez l'aventure !\n");
}

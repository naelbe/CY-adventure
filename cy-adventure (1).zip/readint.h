#ifndef READINT_H
#define READINT_H
int readint(const int minValue, const int maxValue);
int readint1(const int minValue, const int maxValue);
#endif
